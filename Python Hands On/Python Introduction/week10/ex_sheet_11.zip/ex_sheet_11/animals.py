#############################
# UTILITIES                 #
#############################

'''
e.g. a function that reads in the images
'''


#############################
# ANIMALS                   #
#############################

'''
The classes representing animals.
First, define the class hierarchy.
Then think of what the classes have in common,
this functionality goes in the superclass.
Then think of what is special about the subclass,
this goes into the subclass.

Hints: Some methods can be applied to all animals
(e.g., visit(), eat()), some only apply to a particular
animal (e.g., swim()).

Which attributes do the objects have?
--> Design your __init__ methods accordingly.



'''
